import React, { useState } from "react";
import Navigation from "./components/Navigation";
import ProgressBar from "./components/ProgressBar"; // Correct import!
import InputField from "./components/InputField";
import Card from "./components/Card";

import "./styles.css";

export default function App() {
  const [currentStep, setCurrentStep] = useState(0);

  return (
    <div
      className="App"
      style={{
        padding: "40px",
        backgroundColor: "#f8f8f8",
        minHeight: "100vh",
      }}
    >
      <Navigation />
      <ProgressBar currentStep={currentStep} />
      <Card title="File your claim">
        <InputField label="Contract Value" type="number" required unit="USD" />
        <InputField label="Claim Value" type="number" required unit="USD" />
        {/* Add more form elements here */}
      </Card>
      <button
        onClick={() => currentStep < 6 && setCurrentStep(currentStep + 1)}
        style={{
          padding: "10px 20px",
          backgroundColor: "#007bff",
          color: "white",
          border: "none",
          borderRadius: "5px",
          cursor: "pointer",
        }}
      >
        Next Step
      </button>
    </div>
  );
}
