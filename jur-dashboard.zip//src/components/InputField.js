import React, { useState } from "react";

function InputField({ label, type, required, unit }) {
  const [value, setValue] = useState("");
  const handleChange = (e) => setValue(e.target.value);
  return (
    <div style={{ marginBottom: "20px" }}>
      <label
        htmlFor={label}
        style={{
          display: "block",
          marginBottom: "5px",
          fontWeight: "bold",
          color: "#333",
        }}
      >
        {label}
      </label>
      <div style={{ display: "flex" }}>
        <input
          type={type}
          id={label}
          value={value}
          onChange={handleChange}
          required={required}
          style={{
            width: "100%",
            padding: "10px",
            boxSizing: "border-box",
            border: "1px solid #ccc",
            borderRadius: "5px",
            fontSize: "16px",
            outline: "none",
          }}
        />
        {unit && (
          <div
            style={{
              padding: "10px",
              border: "1px solid #ccc",
              borderLeft: "none",
              borderRadius: "0 5px 5px 0",
              backgroundColor: "#eee",
            }}
          >
            {unit}
          </div>
        )}
      </div>
    </div>
  );
}

export default InputField;
