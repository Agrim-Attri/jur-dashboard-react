import React from "react";

const Card = ({ title, children }) => {
  return (
    <div
      style={{
        border: "1px solid #ccc",
        padding: "20px",
        marginBottom: "20px",
      }}
    >
      <h3>{title}</h3>
      {children}
    </div>
  );
};

export default Card;
