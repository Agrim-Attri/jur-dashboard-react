import React from "react";

function ProgressBar({ currentStep }) {
  const steps = [
    "Preliminary",
    "Your Details",
    "KYC",
    "Parties",
    "Claim",
    "Review",
    "Payment",
  ];
  return (
    <div style={{ display: "flex", margin: "20px 0", alignItems: "center" }}>
      {steps.map((step, index) => (
        <div
          key={index}
          style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            flex: 1,
            textAlign: "center",
            color: index <= currentStep ? "#007bff" : "#ccc", // Blue for active
          }}
        >
          <div
            style={{
              width: "20px",
              height: "20px",
              borderRadius: "50%",
              border: "2px solid",
              borderColor: index <= currentStep ? "#007bff" : "#ccc",
              marginBottom: "5px",
            }}
          ></div>
          <span>{step}</span>
          {index < steps.length - 1 && (
            <div
              style={{
                flex: 1,
                height: "2px",
                backgroundColor: index < currentStep ? "#007bff" : "#ccc",
              }}
            />
          )}
        </div>
      ))}
    </div>
  );
}

export default ProgressBar;
