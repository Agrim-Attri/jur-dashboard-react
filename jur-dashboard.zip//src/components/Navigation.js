import React from "react";

function Navigation() {
  return (
    <nav
      style={{
        padding: "20px",
        borderBottom: "1px solid #eee",
        display: "flex",
        alignItems: "center", // Vertically align items
        justifyContent: "space-between",
      }}
    >
      <div style={{ display: "flex", alignItems: "center" }}>
        <div
          style={{
            width: "30px",
            height: "30px",
            backgroundColor: "blue",
            marginRight: "10px",
            borderRadius: "5px",
          }}
        ></div>
        <ul
          style={{ listStyle: "none", padding: 0, margin: 0, display: "flex" }}
        >
          <li style={{ marginRight: "20px", color: "#666" }}>Dashboard</li>
          <li style={{ marginRight: "20px", color: "#666" }}>My Cases</li>
          <li style={{ marginRight: "20px", color: "#666" }}>Activities</li>
          <li style={{ marginRight: "20px", color: "#666" }}>Calendar</li>
          <li style={{ marginRight: "20px", color: "#666" }}>Files</li>
          <li style={{ marginRight: "20px", color: "#666" }}>Open a Dispute</li>
        </ul>
      </div>
      <div style={{ display: "flex" }}>
        <div
          style={{
            width: "20px",
            height: "20px",
            backgroundColor: "grey",
            marginRight: "10px",
            borderRadius: "50%",
          }}
        ></div>
        <div
          style={{
            width: "20px",
            height: "20px",
            backgroundColor: "grey",
            borderRadius: "50%",
          }}
        ></div>
      </div>
    </nav>
  );
}

export default Navigation;
